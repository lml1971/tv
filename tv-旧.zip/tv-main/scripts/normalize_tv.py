#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""normalize_tv.py —— tv.txt 最后一道关卡：归一 / 去重 / 纠偏 / 排序 / 校验。

本版新增（针对「同一频道多套别名」的老问题）：
    1. 名称归一：交给 canonical.canonical_name_keep_label 统一处理，
       CCTV-1 与 CCTV-1 综合、CHC动作电影 与 CHC-动作电影 会在去重环节真正合并。
    2. 错组纠偏：归一后的名称重新判组。老 tv.txt 里的历史残留
       （例如「中」翁立友-独身仔的生活 仍躺在生活频道）无需重抓也会被搬到正确分组。
    3. 固定分组顺序：茂哥TV → 央视频道 → GROUP_ORDER，产物顺序逐日稳定。
"""
import os
import re
import sys

from canonical import (
    canonical_name,
    canonical_name_keep_label,
    split_clarity,
)
from grouping import group_of as _group_of, is_central, GROUP_ORDER

OUTPUT = "tv.txt"
VALID_SCHEMES = ("http://", "https://", "rtp://", "rtsp://", "udp://")
DIRTY = ('"', "group-title=", "tvg-logo=", "tvg-name=", "tvg-id=", "response-time=", "#EXT")
_CCTV = re.compile(r"CCTV[- ]?(\d+)")

# 顺序由人工维护、规范化阶段不得重排 / 不得改名的分组
KEEP_ORDER_GROUPS = ("茂哥TV",)


def is_genre(line: str) -> bool:
    return line.endswith("#genre#") or line.endswith("#genre#,")


def _sort_key(name: str):
    m = _CCTV.search(name)
    if m:
        return (0, int(m.group(1)), 1 if "+" in name else 0, name.lower())
    return (1, 0, 0, name.lower())


def _group_for(name: str) -> str:
    """与 aggregate.group_of 同口径：中央频道单独成组。"""
    return "央视频道" if is_central(name) else _group_of(name)


def _group_sort_index(g: str):
    """固定分组顺序：茂哥TV → 央视频道 → GROUP_ORDER → 其余。"""
    if g in KEEP_ORDER_GROUPS:
        return (0, 0)
    if g == "央视频道":
        return (1, 0)
    if g in GROUP_ORDER:
        return (2, GROUP_ORDER.index(g))
    return (3, 0)


def build(path: str = OUTPUT):
    if not os.path.exists(path):
        print(f"[FATAL] 未找到 {path}，请先运行 aggregate.py", file=sys.stderr)
        sys.exit(1)

    entries, seen, dropped = [], set(), 0
    current = None
    for line in open(path, encoding="utf-8", errors="ignore").read().splitlines():
        line = line.strip()
        if not line:
            continue
        if is_genre(line):
            current = line[:-len("#genre#")].strip().rstrip(",").strip() or "未分组"
            continue
        if line.startswith("#") or "," not in line:
            dropped += 1
            continue
        name, url = (x.strip() for x in line.split(",", 1))
        if not name or not url or not url.startswith(VALID_SCHEMES):
            dropped += 1
            continue
        if any(m in name for m in DIRTY):
            dropped += 1
            continue
        if current is None:
            current = "未分组"

        # ★ 归一放在去重之前：否则「CCTV-1」与「CCTV-1 综合」是两条 key，
        #   永远合并不掉 —— 这正是去重形同虚设的根因。
        if current not in KEEP_ORDER_GROUPS:
            name = canonical_name_keep_label(name)

        key = (current, name, url)
        if key in seen:
            dropped += 1
            continue
        seen.add(key)
        entries.append((current, name, url))

    # ---- 错组纠偏 + 重新分桶 ----
    buckets = {}
    moved = 0
    for g, name, url in entries:
        if g in KEEP_ORDER_GROUPS:
            target = g
        else:
            target = _group_for(name)
            if target != g:
                moved += 1
        buckets.setdefault(target, []).append((name, url))

    # ---- 清晰度标签折叠 ----
    # 抓流实测 / 上游标注会在名称后挂 (1080p)。同组内若同时存在
    # 「CGTN-法语」和「CGTN-法语(1080p)」，对订阅端就是两个频道 —— 正是要消灭的分裂。
    # 折叠规则：同组已有裸名条目时，带标签的别名一律收敛为裸名（并顺带合并重复线路）。
    folded = 0
    for g, items in list(buckets.items()):
        if g in KEEP_ORDER_GROUPS:
            continue
        bare = {nm for nm, _ in items if not split_clarity(nm)[1]}
        merged, seen2 = [], set()
        for nm, url in items:
            if split_clarity(nm)[1]:
                base = canonical_name(nm)
                if base in bare:
                    if base != nm:
                        folded += 1
                    nm = base
            key = (nm, url)
            if key in seen2:
                dropped += 1
                continue
            seen2.add(key)
            merged.append((nm, url))
        buckets[g] = merged
    if folded:
        print(f"[FIX] 清晰度标签折叠 {folded} 条（与同名裸频道合并）")

    groups = []
    for g, items in buckets.items():
        # ★ 茂哥TV 的条目顺序由 mgou_tv.txt 人工维护（受版本控制），
        #   此处若参与排序，会把「幸福家/老李卡通/我们一家/25年前」重排成
        #   「25年前/幸福家/我们一家/老李卡通」，置顶顺序失去意义。
        if g not in KEEP_ORDER_GROUPS:
            items = sorted(items, key=lambda nu: _sort_key(nu[0]))
        groups.append((g, items))
    groups.sort(key=lambda gi: _group_sort_index(gi[0]))

    if moved:
        print(f"[FIX] 名称归一后纠正分组归属 {moved} 条")
    return groups, dropped


def verify(lines):
    for i, raw in enumerate(lines, 1):
        s = raw.strip()
        if not s or is_genre(s):
            continue
        if "," not in s:
            print(f"[FAIL] 第 {i} 行无逗号: {s[:120]}")
            return False
        name, url = (x.strip() for x in s.split(",", 1))
        if not name or not url:
            print(f"[FAIL] 第 {i} 行缺名称/地址: {s[:120]}")
            return False
        if not url.startswith(VALID_SCHEMES):
            print(f"[FAIL] 第 {i} 行地址非法: {s[:120]}")
            return False
    return True


def normalize(path: str = OUTPUT):
    groups, dropped = build(path)
    out = []
    for gi, (g, items) in enumerate(groups):
        if gi > 0:
            out.append("")
        out.append(f"{g},#genre#")
        out += [f"{nm},{url}" for nm, url in items]
    if not verify(out):
        print("存在非标准行，未写入", file=sys.stderr)
        sys.exit(1)
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(out).rstrip() + "\n")
    genres = sum(1 for l in out if l.endswith("#genre#"))
    items = sum(1 for l in out if l.strip() and not l.endswith("#genre#"))
    print(f"[DONE] {path}: {genres} 分组, {items} 条（丢弃 {dropped}）")


if __name__ == "__main__":
    normalize()
