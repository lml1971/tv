#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""grouping.py —— 除「中央频道」以外的分组逻辑。

判定顺序（精确优先 → 关键词兜底）：
    1. 港澳台（不拆分）
    2. 体育赛事（含地方体育，优先于地方台）
    3. 卫视
    4. 音乐（歌曲/演唱会，先于综艺与生活）
    5. 综艺
    6. 精确内容组：影视 → 教育(含自然/科学/纪录) → 生活 → 咪咕
    7. 地方台：命中 REGION_MAP 归省/地区组（要求中文台名形态）
    8. 兜底 → 其他频道

★ 中央频道由调用方先拦截，本模块一律不返回「央视频道」。
★ 名称归一统一收敛到 canonical.py（央视 / CGTN / CETV / CHC）。
  本模块只做 re-export，保证老调用方 `from grouping import canonical_cctv` 照旧可用。
"""
import re
from collections import OrderedDict

from canonical import (  # 名称规范化的唯一真相来源（不反向依赖本模块）
    canonical_name,
    canonical_name_keep_label,
    canonical_cctv,
    canonical_cgtn,
    canonical_chc,
    strip_clarity,
    split_clarity,
)

_SAT = {
    "湖南": "湖南卫视", "浙江": "浙江卫视", "江苏": "江苏卫视", "北京": "北京卫视",
    "上海": "东方卫视", "广东": "广东卫视", "湖北": "湖北卫视", "河南": "河南卫视",
    "山东": "山东卫视", "安徽": "安徽卫视", "四川": "四川卫视", "江西": "江西卫视",
    "辽宁": "辽宁卫视", "吉林": "吉林卫视", "黑龙江": "黑龙江卫视", "天津": "天津卫视",
    "重庆": "重庆卫视", "福建": "东南卫视", "陕西": "陕西卫视", "河北": "河北卫视",
    "山西": "山西卫视", "云南": "云南卫视", "贵州": "贵州卫视", "海南": "海南卫视",
    "甘肃": "甘肃卫视", "新疆": "新疆卫视", "西藏": "西藏卫视", "宁夏": "宁夏卫视",
    "内蒙古": "内蒙古卫视", "广西": "广西卫视", "深圳": "深圳卫视", "厦门": "厦门卫视",
    "三沙": "三沙卫视", "康巴": "康巴卫视", "青海": "青海卫视",
}


# 清晰度 / 制式后缀：判定归属前先剥离。
# 否则「浙江卫视(1080p)」「湖南卫视 HD」「东方卫视(720p)」因不以「卫视」二字结尾，
# 会绕过卫视判定掉进 REGION_MAP，被误归到「浙江地区 / 湖南地区 / 上海地区」。
_RES_SUFFIX_RE = re.compile(
    r"[\(（]\s*\d{2,4}\s*[ip]?\s*[\)）]"
    r"|\bHD\b|\bUHD\b|\bFHD\b|\b4K\b|\b8K\b"
    r"|高清|超清|标清|蓝光",
    re.I,
)


def _strip_res(name: str) -> str:
    return _RES_SUFFIX_RE.sub("", name or "").strip()


def _is_sat(name: str) -> bool:
    n = _strip_res(name)
    if n.endswith("卫视"):
        return True
    return any(n == sat or n == prov + "卫视" for prov, sat in _SAT.items())


_SPORT_KW = (
    "中超", "英超", "西甲", "意甲", "德甲", "法甲", "欧冠", "亚冠", "欧联",
    "NBA", "CBA", "NBL", "WNBA", "中甲", "中乙", "足协杯", "联赛杯",
    "世界杯", "欧洲杯", "亚洲杯", "美洲杯", "奥运", "冬奥", "亚运", "全运",
    "马拉松", "攀岩", "自行车", "赛车", "F1", "拉力赛", "越野", "摩托车",
    "排球", "游泳", "跳水", "田径", "冰雪", "滑雪", "滑冰", "冰壶", "冰球",
    "拳击", "格斗", "搏击", "摔跤", "柔道", "跆拳道", "击剑",
    "网球", "斯诺克", "乒乓", "羽毛球", "棒球", "垒球", "橄榄球", "曲棍球",
    "体操", "举重", "射击", "射箭", "帆船", "赛艇", "皮划艇",
    "围棋", "象棋", "桥牌", "电竞", "电子竞技",
    "足球", "篮球", "台球", "高尔夫", "马术",
    "体坛", "体育", "赛事", "运动", "联赛", "杯赛", "轮播台",
    "回放", "直播", "录播", "集锦", "高光", "精华",
    "决赛", "半决赛", "世锦赛", "锦标赛", "公开赛", "大师赛", "总决赛",
    "全场回放", "全场录像", "赛事回放", "比赛回放", "进球集锦",
    "睛彩", "风云足球", "魅力足球", "游戏风云", "先锋乒羽", "天元围棋",
)


def _is_sports(name: str) -> bool:
    if "体育" in name and not name.endswith("体育高清"):
        if re.search(r"队|VS|vs|对阵|迎战|回放|录像|集锦|直播|比分|战报|高光|德比"
                     r"|联赛|赛事|杯赛|\d{1,3}:\d{1,3}", name):
            return True
    return any(k in name for k in _SPORT_KW)


_MOVIE_KW = (
    "电影", "电视剧", "院线", "纪录片", "动漫", "动画", "CHC", "华数",
    "影视", "剧场", "影院", "重温经典", "老故事", "经典影片", "新片放映", "抗战经典",
    "天映", "淘电影", "淘剧场", "第一剧场", "风云剧场", "都市剧场", "欢笑剧场",
    "变形金刚", "星球大战", "长津湖", "复仇者", "西游记", "水浒传", "三国演义", "红楼梦",
    "射雕英雄传", "天龙八部", "鹿鼎记", "笑傲江湖", "乡村爱情", "刘老根", "武林外传",
    "说电影", "讲电影", "放映厅",
)
_MOVIE_TITLE = (
    "亮剑", "潜伏", "父母爱情", "甄嬛", "还珠", "射雕", "神雕", "倚天", "白蛇", "宝莲灯",
    "神探狄仁杰", "闯关东", "雍正王朝", "大宅门", "大明王朝",
)
_MOVIE_BRACKET = re.compile(r"^「.*?电影.*?」|^《.*?电影.*?》")


def _is_movie(name: str) -> bool:
    if _MOVIE_BRACKET.search(name):
        return True
    if any(k in name for k in _MOVIE_KW + _MOVIE_TITLE):
        return True
    if name.startswith(("电影", "电视剧", "影院", "剧场", "影视", "剧集", "连续剧")):
        return True
    if name.endswith(("剧场", "影院", "影视")):
        return True
    return False


_CROSSTALK = ("小品", "相声", "二人转", "杂技", "魔术", "曲艺", "本山", "贾玲", "开心麻花")
_VARIETY_KW = ("综艺", "娱乐", "选秀", "脱口秀", "戏曲", "梨园")


def _is_variety(name: str) -> bool:
    return any(k in name for k in _CROSSTALK + _VARIETY_KW)


_MUSIC_KW = ("音乐", "MTV", "K歌", "演唱会", "歌手", "金曲", "老歌", "DJ", "舞曲", "串烧",
             "精选", "合集", "歌单", "经典歌曲", "怀旧金曲", "网红歌", "点歌", "翻唱")
_MUSIC_TITLE = ("周杰伦", "邓丽君", "张学友", "刘德华", "陈奕迅", "林俊杰", "薛之谦", "毛不易")

# 歌曲点播频道的命名形态：「中」翁立友-独身仔的生活 / 「台」江蕙-家后 / 「韩」DJ Soda Remix
# 这类名字里常带「生活」「的家」等生活/家居向字眼，若不做形态识别，
# 就会被 _is_life 的「.{2,4}生活$」截走 —— 翁立友正是因此掉进生活频道。
_SONG_FORM_RE = re.compile(r"^[「『\[【].{1,6}[」』\]】]\s*\S+\s*[-－—:]\s*\S+")
_SONG_KW = ("Karaoke", "卡拉OK", "卡拉Ok", "伴奏", "Remix", "MV", "M/V", "Live版",
            "演唱会", "翻唱", "点唱", "音乐欣赏", "钢琴", "吉他", "萨克斯", "二胡", "古筝")
# 台语 / 老歌点播高频歌手（名字里不含任何音乐关键词，只能靠名单兜底）
_SONG_ARTIST = (
    "翁立友", "江蕙", "詹雅雯", "黄乙玲", "蔡秋凤", "陈小云", "阿吉仔", "龙千玉",
    "秀兰玛雅", "蔡小虎", "罗时丰", "张秀卿", "陈思安", "庄学忠", "黄思婷", "林姗",
    "卓依婷", "高胜美", "费玉清", "蔡琴", "凤飞飞", "费翔", "韩宝仪", "龙飘飘",
)


def is_song_like(name: str) -> bool:
    """是否为歌曲 / 点歌类节目（供音乐判定与生活频道净化共用）。"""
    n = (name or "").strip()
    if not n:
        return False
    if _is_movie(n) or _is_sports(n) or _is_edu(n):
        return False                       # 影视 / 体育 / 教育优先，避免误吸
    if _SONG_FORM_RE.match(n):             # 「语种」歌手-曲目
        return True
    if any(a in n for a in _SONG_ARTIST):
        return True
    low = n.lower()
    return any(k.lower() in low for k in _SONG_KW)


def _is_music(name: str) -> bool:
    if is_song_like(name):
        return True
    if any(k in name for k in _MUSIC_KW):
        return True
    if any(t in name for t in _MUSIC_TITLE) and ("的" in name or "金曲" in name or "精选" in name):
        return True
    return False


# 自然 / 科学 / 纪录 —— 先于生活频道截获，避免「星球/宇宙/自然」误归生活
_DOC_KW = (
    "人与自然", "动物世界", "自然传奇", "荒野", "野生动物", "海洋生物", "植物王国",
    "宇宙", "太空", "星球", "天文", "星系", "黑洞", "航天", "NASA",
    "探索", "发现", "未解之谜", "世界地理", "地球", "气候",
    "科学", "科技", "纪录片", "纪录频道", "历史档案", "考古", "文物",
    "兵器", "军事科技", "战史", "兵器科技",
)


def _is_doc(name: str) -> bool:
    return any(k in name for k in _DOC_KW)


_EDU_KW = (
    "中国教育", "CETV", "中央教育", "书画", "文物", "发现之旅", "世界地理",
    "生物多样性", "茶频道", "兵器科技", "文化旅游", "文物宝库", "职业教育", "早期教育",
    "少儿", "动画", "幼儿", "中小学", "大学", "公开课", "读书", "诗词",
)


def _is_edu(name: str) -> bool:
    if re.search(r"CETV|中国教育|中央教育", name):
        return True
    if _is_doc(name):
        return True
    if any(k in name for k in ("少儿", "动画", "幼儿", "中小学", "大学", "公开课", "读书", "诗词")):
        return True
    return any(k in name for k in _EDU_KW)


# 生活频道：收紧，剔除与影视/纪录/旅行交叉的词，要求纯生活语义或「地名+生活」形态
_LIFE_KW = ("钓鱼", "垂钓", "美食", "家居", "养生", "健康", "生活", "特产")


def _is_life(name: str) -> bool:
    # ★ 歌曲点播先剔除：「中」翁立友-独身仔的生活 命中「生活」但不是生活频道
    if is_song_like(name):
        return False
    if any(k in name for k in ("钓鱼", "垂钓", "美食", "家居", "养生", "健康", "特产")):
        return True
    # 「地名 + 生活」形态（如 忻州生活、山西生活）
    if re.search(r".{2,4}生活(频道|台)?$", name) and not _is_movie(name):
        return True
    if name.endswith("生活频道") or name.endswith("生活台"):
        return True
    if name == "生活":
        return True
    return False


REGION_MAP = OrderedDict([
    ("广东", "广东地区"), ("广州", "广东地区"), ("深圳", "广东地区"), ("东莞", "广东地区"),
    ("珠海", "广东地区"), ("佛山", "广东地区"), ("汕头", "广东地区"), ("嘉佳卡通", "广东地区"),
    ("浙江", "浙江地区"), ("杭州", "浙江地区"), ("宁波", "浙江地区"), ("温州", "浙江地区"),
    ("江苏", "江苏地区"), ("南京", "江苏地区"), ("苏州", "江苏地区"), ("无锡", "江苏地区"),
    ("常州", "江苏地区"), ("优漫卡通", "江苏地区"),
    ("安徽", "安徽地区"), ("合肥", "安徽地区"),
    ("四川", "四川地区"), ("成都", "四川地区"), ("四川文旅", "四川地区"),
    ("福建", "福建地区"), ("福州", "福建地区"), ("厦门", "福建地区"), ("东南卫视", "福建地区"),
    ("河北", "河北地区"), ("石家庄", "河北地区"),
    ("山西", "山西地区"), ("太原", "山西地区"),
    # 山西地市台（缺失时会被丢进「其他频道」而整体舍弃）
    ("忻州", "山西地区"), ("大同", "山西地区"), ("阳泉", "山西地区"),
    ("长治", "山西地区"), ("晋城", "山西地区"), ("朔州", "山西地区"),
    ("晋中", "山西地区"), ("运城", "山西地区"), ("临汾", "山西地区"),
    ("吕梁", "山西地区"),
    ("广西", "广西地区"), ("南宁", "广西地区"), ("桂林", "广西地区"),
    ("甘肃", "甘肃地区"), ("兰州", "甘肃地区"),
    ("新疆", "新疆地区"), ("乌鲁木齐", "新疆地区"), ("兵团", "新疆地区"),
    ("北京", "北京地区"), ("BTV", "北京地区"), ("卡酷", "北京地区"),
    ("上海", "上海地区"), ("东方", "上海地区"), ("上海教育", "上海地区"),
    ("陕西", "陕西地区"), ("西安", "陕西地区"),
    ("云南", "云南地区"), ("昆明", "云南地区"),
    ("贵州", "贵州地区"), ("贵阳", "贵州地区"),
    ("河南", "河南地区"), ("郑州", "河南地区"),
    ("湖北", "湖北地区"), ("武汉", "湖北地区"),
    ("湖南", "湖南地区"), ("长沙", "湖南地区"), ("经视", "湖南地区"),
    ("山东", "山东地区"), ("济南", "山东地区"), ("齐鲁", "山东地区"), ("青岛", "山东地区"),
    ("江西", "江西地区"), ("南昌", "江西地区"),
    ("辽宁", "辽宁地区"), ("沈阳", "辽宁地区"), ("大连", "辽宁地区"),
    ("吉林", "吉林地区"), ("长春", "吉林地区"), ("延边", "吉林地区"),
    ("黑龙江", "黑龙江地区"), ("哈尔滨", "黑龙江地区"),
    ("天津", "天津地区"), ("重庆", "重庆地区"),
    ("海南", "海南地区"), ("海口", "海南地区"), ("三沙", "海南地区"),
    ("内蒙古", "内蒙古地区"), ("宁夏", "宁夏地区"), ("西藏", "西藏地区"), ("青海", "青海地区"),
])


def _is_place(name: str) -> bool:
    """地方台判定：要求中文台名形态，避免 WBTV/SBTV/ABTV 等英文缩写误归。"""
    if not re.search(r"[\u4e00-\u9fff]", name):
        return False  # 纯英文/拉丁名不归地方台
    n = name
    if n.startswith(("北京", "上海")):
        # 须接台名后缀，排除节目名（北京大妈有话说）与影视（北京影帝）
        if not re.search(r"(卫视|台|频道|电视台|卡酷|文艺|新闻|纪实|财经|青年|国际|生活|影视|电影|戏曲|体育)", n):
            return False
    if n.startswith("广东") and not re.search(r"(卫视|台|频道|电视台|嘉佳|文旅)", n):
        return False
    return any(kw in n for kw in REGION_MAP)


def group_of(name: str) -> str:
    n = name or ""

    if re.search(r"台湾|台视|民视|华视|三立|中天|非凡|TVBS", n):
        return "台湾地区"
    if re.search(r"香港|TVB|HKT|Now|港台", n):
        return "香港地区"
    if re.search(r"澳门|澳视", n):
        return "澳门地区"

    if _is_sports(n):
        return "文体频道"
    if _is_sat(n):
        return "卫视频道"

    if _is_music(n):
        return "音乐频道"
    if _is_variety(n):
        return "综艺频道"
    if _is_movie(n):
        return "影视频道"
    if _is_edu(n):
        return "教育频道"
    if _is_life(n):
        return "生活频道"
    if "咪咕" in n:
        return "咪咕频道"

    if _is_place(n):
        for kw, region in REGION_MAP.items():
            if kw in n:
                return region

    return "其他频道"


GROUP_ORDER = [
    "卫视频道", "咪咕频道",
    "影视频道", "综艺频道", "音乐频道", "文体频道",
    "教育频道", "生活频道",
    "台湾地区", "香港地区", "澳门地区",
    "广东地区", "上海地区", "北京地区",
    "浙江地区", "江苏地区", "安徽地区", "四川地区", "福建地区",
    "河北地区", "山西地区", "广西地区", "甘肃地区", "新疆地区",
    "湖南地区", "湖北地区", "河南地区", "江西地区", "辽宁地区",
    "吉林地区", "黑龙江地区", "山东地区", "陕西地区", "云南地区",
    "贵州地区", "海南地区", "天津地区", "重庆地区",
    "内蒙古地区", "宁夏地区", "西藏地区", "青海地区",
]


# ==================== 央视频道命名归一（委托 canonical.py）====================
#
# 旧实现内联在本文件里，只覆盖了 CCTV 主频与少量付费频道，导致：
#   CCTV-1 / CCTV-1 综合 并存，CCTV世界地理 / CCTV-世界地理 / CCTV-World Geography 三份，
#   CGTN法语 / CGTN-法语 / CGTN French (1080p) 各写各的，CHC 系列更是四种写法 ——
#   名字不统一，去重就失效，一个频道在 tv.txt 里能散落十几条别名。
# 现统一收敛到 canonical.py（含 CCTV 官方副名补全、英文付费名翻译、
# CGTN 语种归一、CHC 三频道归一），本模块仅 re-export 以兼容既有调用方。
#
# canonical_cctv / canonical_name / canonical_name_keep_label / strip_clarity
# 均由本文件顶部的 `from canonical import ...` 提供。

def is_central(name: str) -> bool:
    """收紧的央视频道判定：要求以中央台标识开头，排除 WCETV/DanceTV 等英文频道。"""
    n = (name or "").strip()
    if not n:
        return False
    if not re.search(r"[\u4e00-\u9fff]", n):
        # 纯英文：仅 CCTV* / CGTN* / CETV* 算中央。
        # ★ CETV 必须列入：canonical_cctv 会把「中国教育电视台」归一为「CETV-1」，
        #   若此处不认，中国教育台会被判为非中央，与 aggregate 的口径相互打架。
        return bool(re.match(r"^(CCTV|CGTN|CETV)", n, re.I))
    if re.match(r"^CCTV", n, re.I):
        return True
    if re.match(r"^CGTN", n, re.I):
        return True
    if re.match(r"^(CETV|中国教育|中央教育)", n, re.I):
        return True
    if n.startswith("央视"):
        return True
    return False


if __name__ == "__main__":
    for t in ["CCTV5+体育赛事", "广东体育", "湖南卫视", "北京卫视", "浙江卫视",
              "TVB翡翠", "民视", "澳视澳门", "风云足球", "第一剧场", "CHC动作电影",
              "江苏综艺", "上海教育电视台", "广东嘉佳卡通", "钓鱼频道", "养生堂",
              "山西卫视", "忻州综合", "周杰伦金曲", "赵本山小品", "熊猫频道", "CCTV-1综合",
              "CCTV1", "CCTV-1 (720p)", "CCTV-4K", "CCTV-4 欧洲", "CCTV-4 美洲",
              "CCTV-5⁺体育赛事", "星球大战9", "宇宙探索飞船", "WBTV News", "WCETV"]:
        print(f"{t:20s} -> {group_of(t)}")
