#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ci_assert.py —— tv.txt 的分组 / 命名断言（供 GitHub Actions 调用）。

用法：
    python scripts/ci_assert.py [tv.txt]

退出码：
    0 = 通过（或仅有警告）
    1 = 存在阻断级违规

设计要点：
    ★ 分级：阻断级（BLOCK）与警告级（WARN）分离。
      上游全部故障时不应让 CI 变红 —— 那时 tv.txt 只有茂哥TV，
      「央视频道必须存在」属于环境性缺失，而非数据性错误。
      设 CI_STRICT=1 可把所有警告升级为阻断。

    ★ 本版新增「名称唯一形态」断言（本次优化的核心诉求）：
      产物里的每个频道名都必须已经是 canonical 规范形态，
      canonical_name_keep_label(nm) != nm 即视为别名残留 ——
      一条断言同时钉死 CCTV / CGTN / CETV / CHC / 清晰度标签五类写法分裂。
      （茂哥TV 由人工维护，豁免。）
"""
import os
import re
import sys

from canonical import canonical_name_keep_label
from grouping import is_song_like

DEFAULT = "tv.txt"
STRICT = os.environ.get("CI_STRICT", "0").lower() in ("1", "true", "yes")
MGOU_FILE = "mgou_tv.txt"
MGOU_GROUP = "茂哥TV"

# 不应出现在「生活频道」的题材关键词
_LIFE_FORBIDDEN = (
    "歌曲", "金曲", "演唱会", "K歌", "MTV", "DJ", "舞曲", "串烧",
    "电影", "电视剧", "影院", "剧场", "影视", "动漫",
    "星球", "宇宙", "太空", "自然", "纪录", "探索",
)

# CHC 官方只有三条，任何其它写法都是别名残留
_CHC_OK = ("CHC-动作电影", "CHC-家庭影院", "CHC-影迷电影")

# 央视频道合法形态（与 grouping.is_central / canonical 保持一致）：
#   - 主频道  ：CCTV-1 综合 / CCTV-5+ 体育赛事 / CCTV-4 欧洲 / CCTV-4K
#   - 付费频道：CCTV-怀旧剧场 / CCTV-风云足球 / 央视-精品
#   - 外语频道：CGTN / CGTN-纪录频道 / CGTN-法语
#   - 教育频道：CETV-1 / CETV-2
#   - 允许带实测标签后缀：CCTV-1 综合(1080p)
_CENTRAL_NAME_RE = re.compile(
    r"^CCTV[- ]\d"      # CCTV-1 ... / CCTV-16 奥林匹克 / CCTV-4K
    r"|^CCTV[^\s\d]"    # CCTV-怀旧剧场（连写付费频道）
    r"|^央视"           # 央视-精品
    r"|^CGTN"           # ★ CGTN / CGTN-法语
    r"|^CETV"           # ★ CETV-1
)

# 仅警告、不阻断的情形
_WARN_MSGS = []


def warn(msg: str):
    _WARN_MSGS.append(msg)


def _load(path: str):
    """返回 (OrderedDict[group] -> [name], [所有 (group,name) 顺序])。"""
    if not os.path.exists(path):
        print(f"[FATAL] 未找到 {path}", file=sys.stderr)
        sys.exit(2)
    groups = {}
    cur = None
    for raw in open(path, encoding="utf-8", errors="ignore"):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.endswith("#genre#"):
            cur = line[:-len("#genre#")].strip().rstrip(",").strip()
            groups.setdefault(cur, [])
            continue
        if "," not in line:
            continue
        nm = line.split(",", 1)[0].strip()
        if cur:
            groups[cur].append(nm)
    return groups


def _load_mgou_names():
    """受版本控制的置顶节目名（顺序即展示顺序）。"""
    if not os.path.exists(MGOU_FILE):
        return []
    names, started = [], False
    for raw in open(MGOU_FILE, encoding="utf-8", errors="ignore"):
        line = raw.strip()
        if not line:
            continue
        if line.endswith("#genre#"):
            started = line[:-len("#genre#")].strip().rstrip(",").strip() == MGOU_GROUP
            continue
        if started and "," in line:
            names.append(line.split(",", 1)[0].strip())
    return names


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT
    groups = _load(path)
    failures = []

    # 1. 生活频道净化（阻断级）
    life = groups.get("生活频道", [])
    for nm in life:
        hit = next((kw for kw in _LIFE_FORBIDDEN if kw in nm), None)
        if hit:
            failures.append(f"[生活频道] 含「{hit}」: {nm}")
        elif is_song_like(nm):
            # 「中」翁立友-独身仔的生活 这类歌曲点播，名称里带「生活」但归音乐
            failures.append(f"[生活频道] 歌曲点播误归生活: {nm}")

    # 2. 央视频道命名规范（阻断级）
    central = groups.get("央视频道", [])
    for nm in central:
        if not _CENTRAL_NAME_RE.match(nm):
            failures.append(f"[央视频道] 名称不规范: {nm}")

    # 3. CHC 三频道统一（阻断级）
    for g, names in groups.items():
        for nm in names:
            if re.match(r"^CHC", nm, re.I) and nm not in _CHC_OK:
                failures.append(f"[{g}] CHC 名称未归一: {nm}（应为 {' / '.join(_CHC_OK)}）")

    # 4. 名称唯一形态（阻断级）：产物里不允许残留任何别名写法
    alias_left = []
    for g, names in groups.items():
        if g == MGOU_GROUP:
            continue  # 人工维护，豁免改名
        for nm in names:
            if canonical_name_keep_label(nm) != nm:
                alias_left.append(f"{g}: {nm} -> {canonical_name_keep_label(nm)}")
    if alias_left:
        shown = alias_left[:20]
        failures.append("[名称规范] 仍存在未归一的别名写法"
                        f"（共 {len(alias_left)} 处，示例：{'；'.join(shown)}）")

    # 5. 不变量：茂哥TV 必须存在且顺序不变（阻断级）
    if MGOU_GROUP not in groups:
        failures.append("[不变量] 缺少「茂哥TV」分组")
    elif not groups[MGOU_GROUP]:
        failures.append("[不变量] 「茂哥TV」分组为空")
    else:
        want = _load_mgou_names()
        got = groups[MGOU_GROUP]
        if want and len(got) < len(want):
            failures.append(f"[不变量] 「茂哥TV」条目缺失 {len(got)}/{len(want)} 条")
        elif want and got[:len(want)] != want:
            failures.append(f"[不变量] 「茂哥TV」顺序被改动：{got[:len(want)]}")

    # 6. 央视频道存在性（警告级 —— 上游全挂时允许缺失，不阻断）
    if "央视频道" not in groups or not central:
        msg = "[环境] tv.txt 缺少央视频道（上游源可能全部不可用）"
        (failures if STRICT else _WARN_MSGS).append(msg)

    # 7. 有效条目数（警告级）
    total = sum(len(v) for v in groups.values())
    if total <= len(groups.get(MGOU_GROUP, [])):
        (failures if STRICT else _WARN_MSGS).append(
            "[环境] 除茂哥TV 外无任何频道（上游源可能全部不可用）")

    uniq_central = len(set(central))
    print("=" * 60)
    if failures:
        print(f"CI ASSERT FAILED ({len(failures)} 项阻断)")
        print("=" * 60)
        for f in failures:
            print("  - " + f)
        for w in _WARN_MSGS:
            print(f"  ! {w} (warn)")
        sys.exit(1)

    print("CI ASSERT PASSED")
    print("=" * 60)
    print(f"  分组数        : {len(groups)}")
    print(f"  总条目        : {total}")
    print(f"  央视频道      : {len(central)} 条 / {uniq_central} 个频道（命名规范）")
    print(f"  生活频道      : {len(life)} 条（无歌曲/电影/纪录误归）")
    print(f"  名称规范      : 无别名残留（CCTV / CGTN / CETV / CHC 均为唯一形态）")
    for w in _WARN_MSGS:
        print(f"  ! {w} (warn, 非阻断；CI_STRICT=1 可升级为阻断)")
    print("=" * 60)
    sys.exit(0)


if __name__ == "__main__":
    main()
