#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""aggregate.py —— 聚合 + 规范化 + 分组（轻量测速、茂哥TV 硬隔离版）。

设计要点（相对旧版）：
    ★ 茂哥TV 隔离不变量：在 regroup_and_write 入口硬性剥离「茂哥TV 组」条目，
      保证其后续【绝不】参与：探测、清晰度门槛、测速、DISCARD 丢弃、
      其他频道舍弃、分组归桶 —— 只原样置顶输出。
      此隔离在函数内部完成（防御性），不依赖调用方已分离。
    ★ 名称规范化：探测后、分桶前接入 canonical_cctv / canonical_name，
      统一央视频道命名，使同名去重真正生效。
    ★ 测速改为轻量级（speed_test_lite）：HTTP HEAD、3s 超时、缓存、
      每频道仅代表线路，避免全量 GET 堆积死机。
    ★ 抓流实测真实分辨率（ffprobe），虚标 >=2 档重写实测标签。
"""
import os
import re
import sys
import time
import urllib.request
from collections import OrderedDict

from grouping import (
    group_of as _group_of,
    GROUP_ORDER,
    canonical_cctv,
    canonical_name,
    canonical_name_keep_label,
    is_central as _is_central_strict,
)  # 分组规则（除中央频道）
# ★ 名称归一统一走 canonical_name_keep_label：
#   1) canonical_cctv 只覆盖央视频道，CHC / CGTN / 清晰度标签一概不管，
#      同一频道在产物里仍是多套别名，去重形同虚设；
#   2) keep_label 版本会把抓流实测写回的 (1080p) 标签保留下来，
#      否则阶段 2 的实测成果在归一那一刻被连标签一起剥掉。
from speed_test_lite import speed_test as lite_speed_test, speed_sort_key
from probe_resolution import probe_batch, relabel_name

SOURCES_FILE = "sources.txt"
OUTPUT = "tv.txt"
RAW_OUTPUT = "tv_raw.txt"
MGOU_GROUP = "茂哥TV"
MGOU_FILE = "mgou_tv.txt"

REQUEST_TIMEOUT = float(os.environ.get("REQUEST_TIMEOUT", "20"))
MAX_RETRY = int(os.environ.get("MAX_RETRY", "2"))
PROBE_WORKERS = int(os.environ.get("PROBE_WORKERS", "8"))
USER_AGENT = "Mozilla/5.0 (compatible; IPTV-Aggregator/2.0)"

DISCARD = {"新动力量创一流", "酒醉的蝴蝶"}

MIN_HEIGHT = int(os.environ.get("MIN_HEIGHT", "720"))

VALID_SCHEMES = ("http://", "https://", "rtp://", "rtsp://", "udp://")
DIRTY_NAME_MARKERS = (
    '"', "group-title=", "tvg-logo=", "tvg-name=",
    "tvg-id=", "response-time=", "#EXT",
)


# ==================== [1] 聚合：抓取源 ====================

def fetch_url(url: str) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
        return resp.read().decode("utf-8", errors="ignore")


def read_local_or_remote(src: str) -> str:
    if src.startswith(("http://", "https://")):
        last_err = None
        for _ in range(MAX_RETRY + 1):
            try:
                return fetch_url(src)
            except Exception as e:
                last_err = e
                time.sleep(1)
        raise RuntimeError(f"下载失败 {src}: {last_err}")
    with open(src, "rb") as f:
        return f.read().decode("utf-8", errors="ignore")


def load_sources(path: str = SOURCES_FILE):
    if not os.path.exists(path):
        print(f"[WARN] 未找到 {path}，跳过抓取", file=sys.stderr)
        return []
    lines = []
    for raw in read_local_or_remote(path).splitlines():
        s = raw.strip()
        if not s or s.startswith("#"):
            continue
        lines.append(s)
    return lines


def parse_m3u_or_txt(text: str):
    """自适应解析 m3u / txt，返回 [(name, url), ...]。"""
    items = []
    lines = text.splitlines()
    is_m3u = any(l.strip().startswith("#EXTM3U") for l in lines[:20]) or \
             sum(1 for l in lines if "#EXTINF" in l) > 3

    if is_m3u:
        pending_name = None
        for raw in lines:
            line = raw.strip()
            if not line:
                continue
            if line.startswith("#EXTINF"):
                _, _, title = line.partition(",")
                pending_name = title.strip() or None
            elif line.startswith("#") or not pending_name:
                continue
            elif line.startswith(VALID_SCHEMES):
                items.append((pending_name or "unknown", line))
                pending_name = None
            else:
                pending_name = None
    else:
        for raw in lines:
            line = raw.strip()
            if not line or line.startswith("#") or "," not in line:
                continue
            name, _, url = line.partition(",")
            name, url = name.strip(), url.strip()
            if name and url:
                items.append((name, url))
    return items


def aggregate(sources):
    merged = OrderedDict()
    success = 0
    for src in sources:
        try:
            text = read_local_or_remote(src)
        except Exception as e:
            print(f"[WARN] 抓取失败，跳过: {src} ({e})", file=sys.stderr)
            continue
        try:
            items = parse_m3u_or_txt(text)
        except Exception as e:
            print(f"[WARN] 解析失败，跳过: {src} ({e})", file=sys.stderr)
            continue
        before = len(merged)
        for name, url in items:
            if url.startswith(VALID_SCHEMES):
                merged[(name, url)] = True
        added = len(merged) - before
        success += 1
        print(f"[FETCH] {src} -> {len(items)} 条，新增 {added}")
    print(f"[AGG] {success}/{len(sources)} 个源成功，合并后 {len(merged)} 条")
    return list(merged.keys())


# ==================== [2] 规范化 ====================

def normalize_text_line(name: str, url: str):
    name, url = name.strip(), url.strip()
    if not name or not url or not url.startswith(VALID_SCHEMES):
        return None
    if any(m in name for m in DIRTY_NAME_MARKERS):
        return None
    return (name, url)


def write_raw(items, path: str = RAW_OUTPUT):
    """调试用：扁平中间产物（仅中央频道排序）。"""
    def _sort_key(name):
        m = re.search(r"CCTV[- ]?(\d+)", name)
        if m:
            return (0, int(m.group(1)), 0, name.lower())
        return (1, 0, 0, name.lower())
    sorted_items = sorted(items, key=lambda nu: _sort_key(nu[0]))
    lines = ["央视频道,#genre#"]
    for name, url in sorted_items:
        lines.append(f"{name},{url}")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines).rstrip() + "\n")


# ==================== [3] 分组 ====================

_CCTV_RE = re.compile(r"^CCTV", re.I)
_CENTRAL_KW = ("CCTV", "CGTN", "中国教育", "CETV", "中央教育", "央视")


def is_central(name: str) -> bool:
    """收紧后的央视频道判定：要求名称以中央台标识开头，避免 WCETV/DanceTV 误归。"""
    return _is_central_strict(name)


def group_of(name: str) -> str:
    """中央频道单独成组，其余走 grouping.py。"""
    return "央视频道" if is_central(name) else _group_of(name)


def cctv_sort_key(name: str):
    m = re.search(r"CCTV[- ]?(\d+)", name)
    if m:
        return (0, int(m.group(1)), 1 if "+" in name else 0, name.lower())
    if "中国教育" in name:
        return (2, 0, 0, name.lower())
    if "CGTN" in name.upper():
        return (3, 0, 0, name.lower())
    return (4, 0, 0, name.lower())


def sort_group(name: str, items, speed_results=None):
    if name == "央视频道":
        return sorted(items, key=lambda x: cctv_sort_key(x[0]))
    if speed_results:
        return sorted(items, key=lambda x: (
            x[0].lower(),
            speed_sort_key(x[1], speed_results)[0],
            speed_sort_key(x[1], speed_results)[1],
        ))
    return sorted(items, key=lambda x: x[0].lower())


def parse_input(text: str):
    """按 #genre# 头解析成 (茂哥TV条目, 其他条目)。"""
    mgou_items, other_items = [], []
    current = None
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.endswith("#genre#"):
            current = line[:-len("#genre#")].strip().rstrip(",").strip() or "未分组"
            continue
        if "," not in line:
            continue
        nm, _, url = line.partition(",")
        nm, url = nm.strip(), url.strip()
        if not url or not url.startswith(VALID_SCHEMES):
            continue
        target = mgou_items if current == MGOU_GROUP else other_items
        target.append((nm, url))
    return mgou_items, other_items


# ==================== [4] 核心：硬隔离聚合输出 ====================

def _load_mgou_items() -> list:
    """读取受版本控制的茂哥TV 置顶节目；缺失则返回空（不阻断）。"""
    if not os.path.exists(MGOU_FILE):
        return []
    try:
        mgou, _ = parse_input(_read_text(MGOU_FILE))
        print(f"[MGOU] 置顶源 {MGOU_FILE} -> {len(mgou)} 条（完全隔离、不参与其他分组）")
        return mgou
    except Exception as e:
        print(f"[WARN] 读取 {MGOU_FILE} 失败: {e}", file=sys.stderr)
        return []


def _read_text(path: str) -> str:
    data = open(path, "rb").read()
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("utf-8", errors="ignore")


def _strip_mgou(items):
    """入口防御：硬性剥离属于「茂哥TV 组」的条目。"""
    others, leaked = [], []
    for nm, url in items:
        (leaked if MGOU_GROUP in (nm or "") else others).append((nm, url))
    if leaked:
        print(f"[MGOU] 入口剥离混入的茂哥TV条目 {len(leaked)} 条（已交由置顶区单独输出）")
    return others


_LABEL_H_RE = re.compile(r"[\(（](\d{2,4})[ip]p?[\)）]", re.I)
_TAG_RE = re.compile(r"[\(（]\d{2,4}[ip]p?[\)）]|HD|UHD", re.I)


def _label_height(nm: str) -> int:
    m = _LABEL_H_RE.search(nm or "")
    return int(m.group(1)) if m else 0


def _write_out(other, mgou_items, dst, speed_results=None, label="[DONE]"):
    """分桶 → 排序 → 写 tv.txt，返回总条数。"""
    speed_results = speed_results or {}
    buckets = OrderedDict()
    discarded = sports_count = 0
    for nm, url in other:
        if not nm or nm in DISCARD:
            discarded += 1
            continue
        g = group_of(nm)
        if g == "文体频道":
            sports_count += 1
        buckets.setdefault(g, OrderedDict())
        buckets[g].setdefault(nm, OrderedDict())
        if url not in buckets[g][nm]:
            buckets[g][nm][url] = (speed_results.get(url) or {}).get("response_time")

    fixed_order = [MGOU_GROUP, "央视频道"] + [g for g in GROUP_ORDER]
    if "其他频道" in buckets:
        dropped = sum(len(v) for v in buckets["其他频道"].values())
        if dropped:
            print(f"[INFO] 舍弃「其他频道」{dropped} 条无法归类的频道")
        del buckets["其他频道"]
    if discarded:
        print(f"[INFO] 舍弃 {discarded} 条黑名单频道")
    if sports_count:
        print(f"[INFO] 体育赛事频道归入「文体频道」{sports_count} 条")

    group_order = [g for g in fixed_order if g in (set(buckets) | {MGOU_GROUP, "央视频道"})]
    group_order += [g for g in buckets if g not in fixed_order]

    lines = []
    for g in group_order:
        if g == MGOU_GROUP:
            items_list = list(mgou_items)
        else:
            grp = buckets.get(g, {})
            flat = [(nm, url) for nm, urls in grp.items() for url in urls]
            items_list = sort_group(g, flat, speed_results=speed_results or None)
        if not items_list:
            continue
        lines.append(f"{g},#genre#")
        for nm, url in items_list:
            lines.append(f"{nm},{url}")
        lines.append("")

    with open(dst, "w", encoding="utf-8") as f:
        f.write("\n".join(lines).rstrip() + "\n")

    total = len(mgou_items) + sum(len(v) for b in buckets.values() for v in b.values())
    print(f"{label} {dst}（茂哥TV 置顶隔离，共 {total} 条）")
    return total


def regroup_and_write(items, dst: str, mgou_items=None):
    if mgou_items is None:
        mgou_items = []
    other = _strip_mgou(items)  # ★ 硬隔离

    # ---- [阶段 0] 名称标签门槛 ----
    # 必须用「原始名称」判定：canonical_cctv 会剥掉 (360p) 这类分辨率标签，
    # 放在归一之后做会让央视频道的低清源全部漏网（快速通道没有实测数据兜底）。
    if MIN_HEIGHT > 0:
        before = len(other)
        other = [(nm, u) for nm, u in other
                 if not _label_height(nm) or _label_height(nm) >= MIN_HEIGHT]
        if before != len(other):
            print(f"[INFO] 名称标签门槛 <{MIN_HEIGHT}p 预筛 {before - len(other)} 条")

    # ★ 名称归一（canonical_cctv）推迟到写出时执行，不再在此处做。
    #   canonical_cctv 会剥掉 (1080p) / (720p) 这类清晰度标签，若在此处归一，
    #   阶段 2 的 _TAG_RE 就再也匹配不到任何标签 —— 而央视频道恰恰是 canonical
    #   的主要作用对象，于是央视整体不参与抓流实测，MIN_HEIGHT 门槛对它们
    #   也只剩「名称标签」这一条兜底路径（enhance job 白跑的深层原因）。
    #   归一仍在写出前完成，产物照样满足 CI 命名断言。

    # ---- [阶段 1] 保底写出 ----
    # 纯 CPU 秒级完成。即使后面的抓流/测速把 job 拖到超时被取消，
    # 仓库里也已经有一份合法、规范、过了门槛的 tv.txt（EARLY_WRITE=false 可关闭）。
    if os.environ.get("EARLY_WRITE", "true").lower() in ("1", "true", "yes"):
        _write_out([(canonical_name_keep_label(nm), u) for nm, u in other],
                   mgou_items, dst, label="[EARLY] 保底写出")

    # ---- [阶段 2] 抓流实测（并发 + 条数/时间双预算）----
    probe_info = {}
    if os.environ.get("DISABLE_PROBE") != "1":
        seen_url, to_probe = set(), []
        for nm, url in other:
            if _TAG_RE.search(nm) and url not in seen_url:
                seen_url.add(url)
                to_probe.append((nm, url))
        if to_probe:
            print(f"[INFO] 抓流实测候选 {len(to_probe)} 条（PROBE_MAX_ITEMS 限流）...")
            results = probe_batch(to_probe, workers=PROBE_WORKERS)
            # ★ 逐条按「自己的名称 + 该 URL 的实测」改名，不能按 url 建映射再回填：
            #   多个频道共用同一条线路时（多源聚合极常见），url 键会互相覆盖，
            #   把 CCTV-3 综艺 也改名为 CCTV-1 综合 —— 同名后又被去重，频道凭空消失。
            relabelled, changed = [], 0
            for nm, url in other:
                new_nm = relabel_name(nm, results.get(url))
                if new_nm != nm:
                    changed += 1
                relabelled.append((new_nm, url))
            other = relabelled
            print(f"[INFO] 清晰度修正 {changed} 条（DISABLE_PROBE=1 可关闭）")
            probe_info = {url: info for _, url in to_probe
                          for info in (results.get(url),) if info}
        else:
            print("[INFO] 无标注清晰度的源，跳过抓流实测")

    # ---- [阶段 3] 清晰度门槛：实测优先，回退名称标签 ----
    def _eff_height(nm: str, info: dict) -> int:
        measured = (info or {}).get("height", 0)
        return measured or _label_height(nm)

    below = kept_fb = 0
    kept = []
    for nm, url in other:
        h = _eff_height(nm, probe_info.get(url))
        if not h:
            kept_fb += 1
            kept.append((nm, url))
        elif h < MIN_HEIGHT:
            below += 1
        else:
            kept.append((nm, url))
    other = kept
    if below:
        print(f"[INFO] 清晰度门槛 <{MIN_HEIGHT}p 舍弃 {below} 条"
              f"（保守保留无标注 {kept_fb} 条）")

    # ---- [阶段 4] 测速择优（并发 + 双预算）----
    speed_results = {}
    if os.environ.get("DISABLE_SPEED") != "1":
        repr_map = OrderedDict()
        for nm, url in other:
            repr_map.setdefault(nm, url)  # 每频道只测一条代表线路
        try:
            speed_results = lite_speed_test(list(repr_map.items()))
        except Exception as e:
            print(f"[WARN] 测速异常，跳过择优: {e}", file=sys.stderr)

    # ---- [阶段 5] 最终写出（此处归一，保证命名满足 CI 断言）----
    _write_out([(canonical_name_keep_label(nm), u) for nm, u in other],
               mgou_items, dst, speed_results=speed_results)


def _bootstrap(dst: str, mgou_items: list):
    """无源可用时的兜底：写出「仅茂哥TV」的种子 tv.txt 并正常退出（ecode 0）。

    保证仓库在任何情况下都有一份可被订阅的产物，工作流不会因首次运行而变红。
    """
    if not mgou_items:
        print("[FATAL] 无可用上游源，且 mgou_tv.txt 为空，无法产出 tv.txt", file=sys.stderr)
        sys.exit(1)
    print(f"[WARN] 无可用上游源且无旧 tv.txt；仅输出茂哥TV 兜底 {len(mgou_items)} 条",
          file=sys.stderr)
    _write_out([], mgou_items, dst, label="[BOOTSTRAP] 仅茂哥TV")
    sys.exit(0)


def main():
    import argparse
    parser = argparse.ArgumentParser(description="聚合 + 规范化 + 分组，产出 tv.txt")
    parser.add_argument("--no-final", action="store_true", help="只产出扁平 tv_raw.txt（调试）")
    parser.add_argument("--in", dest="infile", default=None, help="指定输入文件（跳过抓取）")
    parser.add_argument("--out", dest="outfile", default=OUTPUT, help="最终输出路径")
    args = parser.parse_args()

    mgou_items = _load_mgou_items()

    if args.infile:
        if not os.path.exists(args.infile):
            print(f"[WARN] 输入文件不存在: {args.infile}", file=sys.stderr)
            _bootstrap(args.outfile, mgou_items)
        text = _read_text(args.infile)
        _file_mgou, other = parse_input(text)
        if not other and not _file_mgou:
            other = [(nm.strip(), url.strip())
                     for raw in text.splitlines()
                     if (line := raw.strip()) and "," in line and not line.startswith("#")
                     for nm, _, url in (line.partition(","),)
                     if nm.strip() and url.strip().startswith(VALID_SCHEMES)]
        if _file_mgou:
            mgou_items = list(OrderedDict.fromkeys(mgou_items + _file_mgou))
        items = other
        print(f"[AGG] 从 {args.infile} 读取 {len(items)} 条（跳过抓取）")
    else:
        sources = load_sources()
        if not sources:
            keep = os.environ.get("FORCE_KEEP", "true").lower() in ("1", "true", "yes")
            if keep and os.path.exists(args.outfile):
                print("[WARN] 未找到 sources.txt 且无 --in，FORCE_KEEP 保留旧文件", file=sys.stderr)
                sys.exit(0)
            _bootstrap(args.outfile, mgou_items)
        items = aggregate(sources)
        if not items:
            keep = os.environ.get("FORCE_KEEP", "true").lower() in ("1", "true", "yes")
            # ★ 保底顺序：旧 tv.txt > 茂哥TV 种子 > 失败退出。
            #   旧版在无旧 tv.txt 时直接 sys.exit(1)，新仓库首次运行只要源一抖动，
            #   工作流第一步就红，后续 normalize / assert / push 全部被跳过 ——
            #   这就是「起步就失败」的根因。
            if keep and os.path.exists(args.outfile):
                print("[WARN] 所有源抓取失败；FORCE_KEEP=true，保留旧 tv.txt", file=sys.stderr)
                sys.exit(0)
            _bootstrap(args.outfile, mgou_items)

    cleaned, seen = [], set()
    for pair in (normalize_text_line(nm, url) for nm, url in items):
        if pair is None or pair in seen:
            continue
        seen.add(pair)
        cleaned.append(pair)

    # ★ --no-final 旧版定义了参数却从未使用，README 承诺的 tv_raw.txt 根本不产出。
    if args.no_final:
        write_raw(cleaned)
        print(f"[DONE] 调试中间产物 {RAW_OUTPUT}（{len(cleaned)} 条，跳过分组写入）")
        return

    regroup_and_write(cleaned, args.outfile, mgou_items=mgou_items)


if __name__ == "__main__":
    main()
